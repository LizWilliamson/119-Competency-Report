const firebaseConfig = {
  apiKey: "AIzaSyBBdGaYPAhYeau3VfsAEKl3gFVIIKfDKP0",
  authDomain: "backstory-73b73.firebaseapp.com",
  databaseURL: "https://backstory-73b73.firebaseio.com",
  projectId: "backstory-73b73",
  storageBucket: "backstory-73b73.appspot.com",
  messagingSenderId: "595771584835",
  appId: "1:595771584835:web:48eff7750e420cf7f37ff6",
  measurementId: "G-VWXW54Q7DB"
};

export default firebaseConfig